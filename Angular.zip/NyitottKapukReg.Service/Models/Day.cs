﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NyitottKapukReg.Service.Models
{
    public class Day
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int MaxVisitors { get; set; }
    }
}
