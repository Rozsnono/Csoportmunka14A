﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NyitottKapukReg.Service.Models
{
    public class LoginModel
    {
        public string Email { get; set; }
        public string AdLoginName { get; set; }
        public string Password { get; set; }
    }
}
