export class DayModel {
    
    public id: number | null = null;
    public date: Date | null = null;
    public maxVisitors: number | null = null
}